function output = gety(timeInput)
output = exp(-(timeInput)/sqrt(2)).*cos(timeInput*3);
end