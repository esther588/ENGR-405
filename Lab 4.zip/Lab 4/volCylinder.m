%Calculate cylinder volume
function volume = volCylinder(radius, height);
volume = pi*(radius^2)*height;
end