%Calculate rectangular prism volume
function volume = volRectPrism(length, width, height);
volume = length*width*height;
end