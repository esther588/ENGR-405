%Calculate cube volume
function volume = volCube(length);
volume = length^3;
end