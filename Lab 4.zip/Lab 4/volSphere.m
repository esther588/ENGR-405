%Calculate sphere volume
function volume = volSphere(radius);
volume = (4/3)*pi*(radius^3);
end